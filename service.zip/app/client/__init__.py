from flask import Blueprint

client = Blueprint("client",__name__)

import app.client.views